REFREQ = require 'edifact.message.refreq'
require 'example_edifact_datamap'

require 'edifact.simpleapi'

function main(Data)   
   FillUNA(REFREQ[1])
   FillUIB(REFREQ[2])
   FillMessage(REFREQ[3])
   
   local Transaction = edifact.simpleapi.make(REFREQ)
end

function FillMessage(Data)
   Data.data[1] = Data.data.create()
   FillUIH(Data.data[1][1])
   FillPVD(Data.data[1][3])
   FillPTT(Data.data[1][4])
   Data.data[1][5].data[1] = Data.data[1][5].data.create()
   FillDRU(Data.data[1][5].data[1])
   FillUIT(Data.data[1][8])   
end

function FillPVD(Data)
   Data.data[1] = Data.data.create()
   FillPVDP2(Data.data[1])
   Data.data[2] = Data.data.create()
   FillPVDPC(Data.data[2])
end