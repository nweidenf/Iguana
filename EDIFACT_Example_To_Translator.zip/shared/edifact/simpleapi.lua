edifact.simpleapi={}

local function IsEmpty(I)
   local Data = I.data
   for i = 1, #Data do
      if Data[i].complex then
         if not IsEmpty(Data[i]) then
            return false
         end
      else
         if '' ~= Data[i].value then
            return false
         end
      end
   end  
   
   return true
end

local function RemoveTrailingDelimters(I, Delimiter)
   local SpecialChar = '[\^$.|?*+(){}'
   local RegEx = ''
   if '[' == Delimiter then
      RegEx = '\[+$'
   elseif '\\' == Delimiter then
      RegEx = '\\+$'
   elseif '^' == Delimiter then
      RegEx = '\^+$'
   elseif '$' == Delimiter then
      RegEx = '\$+$'
   elseif '.' == Delimiter then
      RegEx = '\.+$'
   elseif '|' == Delimiter then
      RegEx = '\|+$'
   elseif '?' == Delimiter then
      RegEx = '\?+$'
   elseif '+' == Delimiter then
      RegEx = '\++$'
   elseif '(' == Delimiter then
      RegEx = '\(+$'
   elseif ')' == Delimiter then
      RegEx = '\)+$'
   elseif '{' == Delimiter then
      RegEx = '\{+$'
   elseif '}' == Delimiter then
      RegEx = '\}+$'
   else
      RegEx = Delimiter..'+$'
   end
      
   return I:gsub(RegEx, '')   
end

local function GetData(I, Length, Fixed)
   local ActualLength = #I
   if Length then
      local MaxLength = tonumber(Length)
      if 'true' == Fixed then
         if ActualLength < MaxLength then
            for i = ActualLength + 1, MaxLength do
               I = I..' '
            end
         elseif ActualLength > MaxLength then
            I = I:sub(1, MaxLength)
         end
      else
         if ActualLength > MaxLength then
            I = I:sub(1, MaxLength)
         end 
      end
   end
   
   return I
end

local function BuildSegmentUNA(I)
   local Segment = 'UNA'
   local Data = I.data
   for i = 1, #Data do
      Segment = Segment..Data[i].value
   end  
   
   return Segment
end

local function BuildSegmentUIZ(I)
   local Segment = 'UIZ++'
   for i = 1, #I do
      if I[i].message then
         Segment = Segment..#I[i].data..'\''
      end
   end   
   
   return Segment
end

local function BuildSegment(I, ComponentSeparator, ElementSeparator)
   function Build(Data, ComponentSeparator, ElementSeparator)
      local Segment = ''
      local CurrentPosition = 1
      for i = 1, #Data do
         for j = CurrentPosition, tonumber(Data[i].position) - 1 do
            Segment = Segment..ElementSeparator
         end
         CurrentPosition = tonumber(Data[i].position)
         if Data[i].complex then
            local Data2 = Data[i].data
            for j = 1, #Data2 do
               Segment = 
               Segment..GetData(Data2[j].value, Data2[j].length, 
                  Data2[j].fixed)..ComponentSeparator
            end
            Segment = RemoveTrailingDelimters(Segment, ComponentSeparator)
         else
            Segment = 
            Segment..GetData(Data[i].value, Data[i].length, Data[i].fixed)
         end
      end  
      
      local SegmentContent = RemoveTrailingDelimters(Segment, ElementSeparator)
      if '' == SegmentContent then
         return '\''
      else
         return ElementSeparator..SegmentContent..'\''
      end
   end
   
   if I.group or I.message then
      local Segments = ''
      local Data1 = I.data
      for i = 1, #Data1 do
         Segments = Segments..edifact.simpleapi.make(Data1[i])
      end
      return Segments
   else
      local Data1 = I.data
      local CurrentPosition = 1
      local Segment = ''
      if Data1[1].position then
         Segment = I.segment
         Segment = Segment..Build(Data1, ComponentSeparator, ElementSeparator)
      else
         for i = 1, #Data1 do
            Segment = Segment..I.segment
            Segment = Segment..Build(Data1[i], ComponentSeparator, ElementSeparator)
         end
      end
         
      return Segment
   end   
end

function edifact.simpleapi.make(I)
   local Message = ''
   local ComponentSeparator = ':'
   local ElementSeparator = '+'
   local StartIndex = 1
   if 'UNA' == I[1].segment then
      if 'true' == I[1].mandatory or not IsEmpty(I[1]) then
         Message = Message..BuildSegmentUNA(I[1])
         ComponentSeparator = I[1].data[1].value
         ElementSeparator = I[1].data[2].value
         StartIndex = 2
      end
   end
   for i = StartIndex, #I do
      if 'UIZ' == I[i].segment then
         if 'true' == I[i].mandatory or not IsEmpty(I[i]) then
            Message = Message..BuildSegmentUIZ(I)
         end
      else
         if 'true' == I[i].mandatory or not IsEmpty(I[i]) then
            Message = Message..BuildSegment(I[i], 
               ComponentSeparator, ElementSeparator)
         end
      end
   end
   
   print(Message:gsub('\'', '\'\n'))
   
   return Message
end
