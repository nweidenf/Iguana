require 'edifact.segment'

--[[

REFREQ definition

Some elements have a cardinality of > 1 so create elements are provided within the subtables 
eg. PVD segment.  Look in the example_edifact_datamap module for examples of how to create 
multiple segments of the same type.Similarly, there can be multiple message within a single 
transaction.  Again, example_edifat_datamap has an example of how to do that.

]]

local function createREFREQMessage()
   return {
      {segment='UIH', mandatory='true', data=edifact.segment.createUIH()},
      {segment='REQ', mandatory='false', data=edifact.segment.createREQ()},
      {segment='PVD', mandatory='true', data={create=edifact.segment.createPVD}},
      {segment='PTT', mandatory='true', data=edifact.segment.createPTT()},  
      {segment='DRU', mandatory='true', data={create=edifact.segment.createDRU}},
      {segment='OBS', mandatory='false', data=edifact.segment.createOBS()},
      {segment='COO', mandatory='false', data=edifact.segment.createCOO()},      
      {segment='UIT', mandatory='true', data=edifact.segment.createUIT()}
   }
end

return {
   {segment='UNA', mandatory='true', data=edifact.segment.createUNA()},
   {segment='UIB', mandatory='true', data=edifact.segment.createUIB()},
   {message='REFREQ', mandatory='true', data={create=createREFREQMessage}},  
   {segment='UIZ', mandatory='true'}   
}
