require 'edifact.segment'

--[[

NEWRX definition

Some elements have a cardinality of > 1 so create elements are provided within the subtables 
eg. PVD segment.  Look in the example_edifact_datamap module for examples of how to create 
multiple segments of the same type.Similarly, there can be multiple message within a single 
transaction.  Again, example_edifat_datamap has an example of how to do that.

]]

local function createNEWRXMessage()
   return {
      {segment='UIH', mandatory='true', data=edifact.segment.createUIH()},
      {segment='STS', mandatory='false', data=edifact.segment.createSTS()},
      {segment='PVD', mandatory='false', data={create=edifact.segment.createPVD}},
      {segment='PTT', mandatory='false', data=edifact.segment.createPTT()},  
      {segment='DRU', mandatory='false', data={create=edifact.segment.createDRU}},   
      {segment='UIT', mandatory='true', data=edifact.segment.createUIT()}
   }
end

return {
   {segment='UNA', mandatory='true', data=edifact.segment.createUNA()},
   {segment='UIB', mandatory='true', data=edifact.segment.createUIB()},
   {message='NEWRX', mandatory='true', data={create=createNEWRXMessage}},  
   {segment='UIZ', mandatory='true'}   
}
