edifact={}
edifact.segment={}

--[[
Segment definitions

Elements can be simple or complex.  The latter is made up of multiple data items 
separated by whereas the former represents a single piece of data.  Complex elements 
are denoted in the tables below as those subtables with a complex table element. 

]]

function edifact.segment.createUNA()
   return {
      {name='Component Data Element Separator', value='', length='1', fixed='true', mandatory='true', position='1'},
      {name='Data Element Separator', value='', length='1', fixed='true', mandatory='true', position='1'},
      {name='Decimal Notation', value='', length='1', fixed='true', mandatory='true', position='1'}, 
      {name='Release Indicator', value='', length='1', fixed='true', mandatory='true', position='1'}, 
      {name='Repetition Separator', value='', length='1', fixed='true', mandatory='true', position='1'}, 
      {name='Segment Separator ', value='', length='1', fixed='true', mandatory='true', position='1'}
   }
end

function edifact.segment.createUIB()
   return {
      {complex='Syntax', mandatory='true', position='1', data={
            {name='Syntax identifier', value='', length='4', fixed='true', mandatory='true'},
            {name='Syntax version Number', value='', length='1', fixed='true'}
         }
      },
      {complex='Transaction Control', mandatory='true', position='3', data={ 
            {name='Transaction control reference', value='', mandatory='true'},            
            {name='Initiator reference identifier', value='', mandatory='false'},
            {name='Controlling agency', value='', mandatory='false'},
         }
      },
      {complex='Interchange Sender', mandatory='true', position='6', data={ 
            {name='Level one', value='', mandatory='true'},            
            {name='Level one identification code', value='', mandatory='true'},
            {name='Level two', value='', mandatory='false'},
            {name='Level three', value='', mandatory='false'}
         }
      },
      {complex='Interchange Recipient', mandatory='true', position='7', data={ 
            {name='Level one', value='', mandatory='true'},            
            {name='Level one identification code', value='', mandatory='true'},
            {name='Level two', value='', mandatory='false'},
            {name='Level three', value='', mandatory='false'}
         }
      },      
      {complex='Date/Time of Message', mandatory='false', position='8', data={
            {name='Date of initiation', value='', length='8', fixed='true', mandatory='false'},
            {name='Event Time', value='', length='8', fixed='true', mandatory='false'}
         }
      },
      {name='Test Indicator', value='', mandatory='false', position='10'}
   }
end

function edifact.segment.createUIH()
   return {
      {complex='Interactive Message Identifier', mandatory='true', position='1', data={
            {name='Message Type', value='', mandatory='true'},
            {name='Message Version Number', value='', mandatory='true'},
            {name='Message Release Number', value='', mandatory='true'},
            {name='Message Type Sub-function Identification', value='', mandatory='false'},           
            {name='Controlling Agency', value='', mandatory='false'},
            {name='Assigned Code', value='', mandatory='false'}
         }
      },
      {name='Interactive Message Reference Number', value='', mandatory='false', position='2'},
      {complex='Dialogue Reference', value='', position='3', mandatory='false', data={
            {name='Initiator Control Reference', value='', mandatory='true'},
            {name='Controlling Agency', value='', mandatory='false'},
            {name='Responder Control Reference', value='', mandatory='false'}
         }
      },
      {complex='Status of Transfer', value='', position='4', mandatory='false', data={
            {name='Sender Sequence Number', value='', mandatory='false'},
            {name='Transfer Position', value='', mandatory='false'},
            {name='Duplicate Indicator', value='', mandatory='false'}            
         }
      },
      {complex='Date and/or Time of Initiation', value='', mandatory='false', position='5', data={
            {name='Event Date', value='', mandatory='false'},
            {name='Event Time', value='', mandatory='false'},
            {name='Time Offset', value='', mandatory='false'}            
         }
      },
      {name='Test Indicator', value='', position='6', mandatory='false'}
   }
end

function edifact.segment.createSTS()
   return {
      {name='Status Type', value='', mandatory='false', position='1'},
      {name='Code List Qualifier', value='', mandatory='false', position='2'},
      {name='Free Text', value='', mandatory='false', position='3'}
   }
end

function edifact.segment.createREQ()
   return {
      {name='Message Function', value='', mandatory='false', position='1'},
      {name='Code List Qualifier', value='', mandatory='false', position='2'},
      {name='Reference Number', value='', mandatory='false', position='3'}, 
      {name='Sender Identification - level two - Old Password', value='', mandatory='false', position='4'}, 
      {name='Sender Identification - level two - New Password', value='', mandatory='false', position='5'} 
   }
end

function edifact.segment.createPVD()
   return {
      {name='Provider Coded', value='', mandatory='false', position='1'},
      {complex='Reference Number', mandatory='false', position='2', data={ 
            {name='Transaction control reference', value='', mandatory='true'},            
            {name='Initiator reference identifier', value='', mandatory='false'},
            {name='Controlling agency', value='', mandatory='false'},
         }
      },         
      {complex='Prescriber Name', mandatory='false', position='5', data={
            {name='Party Name', value='', mandatory='false'},            
            {name='First', value='', mandatory='false'},
            {name='Middle', value='', mandatory='false'},    
            {name='Suffix', value='', mandatory='false'},               
            {name='Prefix', value='', mandatory='false'}                              
         }
      },
      {name='Clinic or Pharmacy Name', value='', mandatory='false', position='7'},  
      {complex='Address', mandatory='false', position='8', data={
            {name='Street and Number/P.O. Box', value='', mandatory='false'}, 
            {name='City', value='', mandatory='false'}, 
            {name='State', value='', mandatory='false'}, 
            {name='Postcode', value='', mandatory='false'},
            {name='Place/Location Qualifier', value='', mandatory='false'},    
            {name='Place/Location', value='', mandatory='false'}                       
         }
      }, 
      {complex='Communication Number', mandatory='false', position='9', data={
            {name='Communication Number', value='', mandatory='false'},            
            {name='Code List Qualifier', value='', mandatory='false'}                  
         }
      },  
      {complex='Agent Name', mandatory='false', position='10', data={
            {name='Party Name', value='', mandatory='false'},            
            {name='First', value='', mandatory='false'},
            {name='Middle', value='', mandatory='false'},    
            {name='Prefix', value='', mandatory='false'},               
            {name='Suffix', value='', mandatory='false'}                              
         }
      }            
   }
end

function edifact.segment.createPTT()
   return {
      {name='Individual Relationship', value='', mandatory='false', position='1'},
      {name='Birth date', value='', length='8', fixed='true', mandatory='false', position='2'},
      {complex='Patient Name', mandatory='true', position='3', data={
            {name='Last', value='', mandatory='false'},            
            {name='First', value='', mandatory='false'},
            {name='Middle', value='', mandatory='false'},    
            {name='Suffix', value='', mandatory='false'},               
            {name='Prefix', value='', mandatory='false'}                              
         }
      },
      {name='Gender', value='', length='1', fixed='true', mandatory='false', position='4'},      
      {complex='Reference Number', mandatory='true', position='5', data={
            {name='Reference Number', value='', mandatory='true'},            
            {name='Code List Qualifier', value='', mandatory='false'}                  
         }
      },    
      {complex='Address', mandatory='false', position='6', data={
            {name='Street and Number/P.O. Box', value='', mandatory='false'},
            {name='City', value='', mandatory='false'}, 
            {name='State', value='', mandatory='false'},             
            {name='Postcode', value='', mandatory='false'},
            {name='Place/Location Qualifier', value='', mandatory='false'},    
            {name='Place/Location', value='', mandatory='false'}                       
         }
      }, 
      {complex='Communication Number', mandatory='false', position='7', data={
            {name='Communication Number', value='', mandatory='false'},            
            {name='Code List Qualifier', value='', mandatory='false'}                  
         }
      }       
   }
end

function edifact.segment.createDRU()
   return {
      {complex='Item Description', mandatory='true', position='1', data={
            {name='Identification', value='', length='1', fixed='true', mandatory='true'},            
            {name='Information - primary', value='', mandatory='true'},
            {name='Item Number', value='', mandatory='false'},    
            {name='Code List Responsibility Agency', value='', mandatory='false'},               
            {name='Code List Qualifier', value='', mandatory='false'},
            {name='Free Text', value='', mandatory='false'},    
            {name='Code List Qualifier', value='', mandatory='false'},               
            {name='Reference Number', value='', mandatory='false'},
            {name='Reference Qualifier', value='', mandatory='false'},    
            {name='Item Description', value='', mandatory='false'},               
            {name='Item Description', value='', mandatory='false'},
            {name='Item Description', value='', mandatory='false'}                        
         }
      },  
      {complex='Quantity', mandatory='false', position='2', data={
            {name='Qualifier', value='', mandatory='true'},            
            {name='Quantity', value='', mandatory='true'},
            {name='Code List Qualifier', value='', mandatory='false'}
         }
      },
      {complex='Directions', mandatory='false', position='3', data={               
            {name='Dosage Identification', value='', mandatory='false'},
            {name='Dosage', value='', mandatory='false'},    
            {name='Dosage', value='', mandatory='false'}                 
         }
      },
      {complex='Date', mandatory='false', position='4', data={
            {name='Qualifier', value='', mandatory='false'},
            {name='Date/Time/Period', value='', mandatory='false'},    
            {name='Format Qualifier', value='', mandatory='false'}             
         }
      }, 
      {name='Product/Service Substitution', value='', mandatory='false', position='5'},
      {complex='Refill Quantity', mandatory='false', position='6', data={
            {name='Qualifier', value='', mandatory='true'},            
            {name='Quantity', value='', mandatory='true'}
         }
      },
      {complex='Clinical Information', mandatory='false', position='7', data={
            {name='Qualifier', value='', mandatory='true'},            
            {name='Information - primary', value='', mandatory='true'},
            {name='Code List Qualifier', value='', mandatory='false'},    
            {name='Information - secondary', value='', mandatory='false'},               
            {name='Code List Qualifier', value='', mandatory='false'}                    
         }
      },
      {complex='Reference Number', mandatory='false', position='8', data={
            {name='Reference Number', value='', mandatory='true'},            
            {name='Qualifier', value='', mandatory='false'}
         }
      },
      {name='Free Text', value='', mandatory='false', position='9'},
      {complex='Drug Use Evaluation', mandatory='false', position='10', data={
            {name='DUE Reason For Service Code', value='', mandatory='true'},            
            {name='DUE Professional Service Code', value='', mandatory='false'},
            {name='DUE Result Of Service Code', value='', mandatory='false'},    
            {name='DUE Co-Agent ID', value='', mandatory='false'},               
            {name='DUE Co-Agent ID Qualifier', value='', mandatory='false'}                    
         }
      },    
      {name='Drug Coverage Status Code', value='', mandatory='false', position='11'}
   }
end

function edifact.segment.createOBS()
   return {
      {complex='Measurement', mandatory='false', position='10', data={
            {name='Measurement Dimension', value='', mandatory='true'},            
            {name='Measurement Value', value='', mandatory='true'},
            {name='Measurement Unit Qualifier', value='', mandatory='true'},    
            {name='Date/Time/Period', value='', mandatory='false'},               
            {name='Date/Time/Period Format Qualifier', value='', mandatory='false'}
         }
      }
   }
end

function edifact.segment.createCOO()
   return {
      {complex='Reference Number', mandatory='false', position='1', data={
            {name='Reference Number', value='', mandatory='true'},            
            {name='Reference Qualifier', value='', mandatory='false'}
         }
      },
      {name='Payer Name', value='', mandatory='false', position='2'},
      {name='Cardholder ID', value='', mandatory='false', position='4'},
      {name='Cardholder Name', value='', mandatory='false', position='5'}, 
      {name='Group ID', value='', mandatory='false', position='6'}, 
      {name='Group Name', value='', mandatory='false', position='7'}, 
      {name='Address - Payer (unused)', value='', mandatory='false', position='8'},
      {complex='Date/Time/Period', mandatory='false', position='9', data={
            {name='Date/Time Period Qualifier', value='', mandatory='false'},            
            {name='Date/Time/Period', value='', mandatory='false'},
            {name='Date/Time/Period Format Qualifier', value='', mandatory='false'}            
         }
      },
      {name='Address - Cardholder (unused)', value='', mandatory='false', position='10'}, 
      {name='Condition/Response', value='', mandatory='false', position='13'}, 
      {name='Patient Identifier', value='', mandatory='false', position='14'},       
   }
end

function edifact.segment.createUIT()
   return {
      {name='Number of Segments in the Message', value='', mandatory='false', position='1'},         
      {name='Message Reference Number', value='', mandatory='false', position='2'}
   }
end

-- Add more segment definitions here