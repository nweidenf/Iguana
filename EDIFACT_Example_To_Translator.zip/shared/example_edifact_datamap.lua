function FillUNA(UNA)
   UNA.data[1].value = ':'
   UNA.data[2].value = '+'
   UNA.data[3].value = '\\'
   UNA.data[4].value = '*'
   UNA.data[5].value = '\''
end

function FillUIB(UIB)
   UIB.data[1].data[1].value = 'UNOA'
   UIB.data[1].data[2].value = '0'
   UIB.data[2].data[1].value = '6e953e603be4467a9dfd725a7765958d'
   UIB.data[3].data[1].value = '27255840004'
   UIB.data[3].data[2].value = 'D'
   UIB.data[4].data[1].value = '9998888'
   UIB.data[4].data[2].value = 'P'
   UIB.data[5].data[1].value = '2006 0313'
   UIB.data[5].data[2].value = '225630,3'
end

function FillUIH(UIH)
   UIH.data[1].data[1].value = 'SCRIPT'
   UIH.data[1].data[2].value = '008'
   UIH.data[1].data[3].value = '001'
   UIH.data[1].data[4].value = 'REFREQ'
   UIH.data[2].value = '600512'
end

function FillPVDP2(PVD)
   PVD[1].value = 'P2'
   PVD[2].data[1].value = '9998888'
   PVD[2].data[2].value = 'D3'
   PVD[4].value = '4X Pharmacy'
   PVD[5].data[1].value = '12345 Mountain Road'
   PVD[5].data[2].value = 'Alexandria'
   PVD[5].data[3].value = 'VA'
   PVD[5].data[4].value = '22315'
   PVD[6].data[1].value = '7039212121:TE*2164444380'
   PVD[6].data[2].value = 'FX'
end

function FillPVDPC(PVD)
   PVD[1].value = 'PC'
   PVD[2].data[1].value = '6827255840004'
   PVD[2].data[2].value = 'SPI'
   PVD[3].data[1].value = 'RefillChange'
   PVD[3].data[2].value = 'SureScripts'
   PVD[3].data[3].value = 'Test'
   PVD[3].data[4].value = 'MD'
   PVD[3].data[5].value = 'DR'
   PVD[5].data[1].value = '4690 Parkway Dr.'
   PVD[5].data[2].value = 'PRESCRIBER CITY'
   PVD[5].data[3].value = 'OH'
   PVD[5].data[4].value = '45040'
   PVD[6].data[1].value = '5132295500:TE*5132295505'
   PVD[6].data[2].value = 'FX'   
end

function FillPTT(PTT)
   PTT.data[2].value = '19620122' 
   PTT.data[3].data[1].value = 'Tucker'
   PTT.data[3].data[2].value = 'Debra'
   PTT.data[3].data[5].value = 'Ms.'
   PTT.data[4].value = 'F'
   PTT.data[5].data[1].value = '6532865'
   PTT.data[5].data[2].value = '94'
   PTT.data[6].data[1].value = '8331 Everwood Dr. Apt. 342'
   PTT.data[6].data[2].value = 'Cleveland'
   PTT.data[6].data[3].value = 'OH'
   PTT.data[6].data[4].value = '44103'
   PTT.data[7].data[1].value = '4408450398'
   PTT.data[7].data[2].value = 'TE'
end

function FillDRU(DRU)
   DRU[1].data[1].value = 'P'
   DRU[1].data[2].value = 'Lipitor 40mg Tablets'
   DRU[1].data[3].value = '00071015723'
   DRU[1].data[4].value = 'ND'
   DRU[1].data[5].value = '10'
   DRU[1].data[6].value = '40'
   DRU[1].data[7].value = 'ME'
   DRU[2].data[1].value = 'U2'
   DRU[2].data[2].value = '60'
   DRU[3].data[2].value = 'Take one tablet daily.'
   DRU[4].data[1].value = 'ZDS:60:804*85'
   DRU[4].data[2].value = '20040130'
   DRU[4].data[3].value = '102'
   DRU[5].value = '1'
   DRU[6].data[1].value = 'R'
   DRU[6].data[2].value = '1'
end

function FillUIT(UIT)
end
